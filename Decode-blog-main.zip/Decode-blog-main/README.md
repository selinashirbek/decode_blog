# How to start?
### Start database named 'blog_basee' in pg-admin(PostgreSQL)

> pip install -r requirements.txt

> py manage.py migrate

> py manage.py makemigrations

> py manage.py runserver
